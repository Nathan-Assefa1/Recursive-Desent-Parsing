
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import java.io.*;

public class Sphere extends Frame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6236779779525803103L;
	JFrame f = new JFrame("Sphere");

	public Sphere() {
		f.setLayout(new FlowLayout());
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(300,400);

		//Credit to: https://stackoverflow.com/questions/14353302/displaying-image-in-java
		//and textbook source code example (Chapter 32)
		 BufferedImage img = null;
			try {
				img = ImageIO.read(new File("C:\\Users\\Nathan\\eclipse-workspace\\Testing\\src\\Sphere.jpg"));
			} catch (IOException e) {
				System.err.println("File Not Found");
			}
		ImageIcon c = new ImageIcon(img);
		JLabel jl = new JLabel("Sphere", c, JLabel.CENTER);
		f.add(jl);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
		
		f.setVisible(true);
	}
}
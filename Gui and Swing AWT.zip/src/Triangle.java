
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.event.*;
import java.awt.*;

@SuppressWarnings("serial")
public class Triangle extends Frame {
	JFrame f = new JFrame("Triangle");
	int first_x, first_y, second_x, second_y, third_x, third_y, b;

	public Triangle() {
		super("Triangle");
		setSize(700,700);

		setFirstCoordinate();

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
	}
	

	public void paint(Graphics g) {
		g.drawLine(first_x, first_y, second_x, second_y);
		g.drawLine(second_x, second_y, third_x, third_y);
		g.drawLine(third_x, third_y, first_x, first_y);
		

	}

	public void setFirstCoordinate() {
		JFrame f = new JFrame("Enter First Coordinate");
		JPanel f1 = new JPanel();
		f1.setLayout(new FlowLayout());
		f.setSize(500,200);
		f.setLayout(new GridLayout(0,1));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(500,200);
		
		JLabel head = new JLabel("Each Value should be between 50-600 for best output", SwingConstants.CENTER);
		f.add(head);
		JLabel l1 = new JLabel("X: ");
		f1.add(l1);
		JTextField t1 = new JTextField(10);
		f1.add(t1);
		f.add(f1);
		JLabel l2 = new JLabel("Y: ");
		f1.add(l2);
		JTextField t2 = new JTextField(10);
		f1.add(t2);
		f.add(f1);
		JButton b1 = new JButton("Submit");
		f.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String userInput = t1.getText();
				first_x = Integer.parseInt(userInput.trim());
				userInput = t2.getText();
				first_y = Integer.parseInt(userInput.trim());
				f.setVisible(false);
				setSecondCoordinate();
			}
		});				

		f.setVisible(true);
	}
	
	public void setSecondCoordinate() {
		JFrame f = new JFrame("Enter Second Coordinate");
		JPanel f1 = new JPanel();
		f1.setLayout(new FlowLayout());
		f.setSize(500,200);
		f.setLayout(new GridLayout(0,1));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(500,200);
		
		JLabel head = new JLabel("Each Value should be between 50-600 for best output", SwingConstants.CENTER);
		f.add(head);
		JLabel l1 = new JLabel("X: ");
		f1.add(l1);
		JTextField t1 = new JTextField(10);
		f1.add(t1);
		f.add(f1);
		JLabel l2 = new JLabel("Y: ");
		f1.add(l2);
		JTextField t2 = new JTextField(10);
		f1.add(t2);
		f.add(f1);
		JButton b1 = new JButton("Submit");
		f.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String userInput = t1.getText();
				second_x = Integer.parseInt(userInput.trim());
				userInput = t2.getText();
				second_y = Integer.parseInt(userInput.trim());
				f.setVisible(false);
				setThirdCoordinate();
			}
		});				

		f.setVisible(true);	}
	
	public void setThirdCoordinate() {
		JFrame f = new JFrame("Enter Third Coordinate");
		JPanel f1 = new JPanel();
		f1.setLayout(new FlowLayout());
		f.setSize(500,200);
		f.setLayout(new GridLayout(0,1));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(500,200);
		
		JLabel head = new JLabel("Each Value should be between 50-600 for best output", SwingConstants.CENTER);
		f.add(head);
		JLabel l1 = new JLabel("X: ");
		f1.add(l1);
		JTextField t1 = new JTextField(10);
		f1.add(t1);
		f.add(f1);
		JLabel l2 = new JLabel("Y: ");
		f1.add(l2);
		JTextField t2 = new JTextField(10);
		f1.add(t2);
		f.add(f1);
		JButton b1 = new JButton("Submit");
		f.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String userInput = t1.getText();
				third_x = Integer.parseInt(userInput.trim());
				userInput = t2.getText();
				third_y = Integer.parseInt(userInput.trim());
				f.setVisible(false);
				showTriangle();
			}
		});				

		f.setVisible(true);
	}

	public void showTriangle() {
		repaint();
		setVisible(true);
		
	}
}
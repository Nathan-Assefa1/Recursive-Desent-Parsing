
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import java.io.*;

@SuppressWarnings("serial")
public class Cube extends Frame {
	JFrame f = new JFrame("Cone");

	public Cube() {
		f.setLayout(new FlowLayout());
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(300,300);

		//Credit to: https://stackoverflow.com/questions/14353302/displaying-image-in-java
		//and textbook source code example (Chapter 32)
		 BufferedImage img = null;
			try {
				img = ImageIO.read(new File("C:\\Users\\Nathan\\eclipse-workspace\\Testing\\src\\Cube.png"));
			} catch (IOException e) {
				System.err.println("File Not Found");
			}
		ImageIcon c = new ImageIcon(img);
		JLabel jl = new JLabel("Cube", c, JLabel.CENTER);
		f.add(jl);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
		
		f.setVisible(true);
	}
}
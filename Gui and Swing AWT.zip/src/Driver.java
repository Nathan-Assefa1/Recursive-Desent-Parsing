/*
 * File Name: Driver.java
 * Date: 11/01/2022
 * Author: Nathan Assefa
 * Purpose: To create a command driven menu w/ outputs
 */


import javax.swing.*;

import java.time.format.DateTimeFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;   

public class Driver{
	static String input = "";
	int d;
	public Driver() {
		JFrame f = new JFrame("Shapes");
		f.setLayout(new GridLayout(0, 1));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(400,400);
	
		
		JLabel h1 = new JLabel("****Welcome to the Java OO Shapes Program ****\n");
		f.add(h1);
		JLabel h2 = new JLabel("Select from the menu below: \n");
		f.add(h2);
		JLabel fO = new JLabel("1. Construct a Circle\n");
		f.add(fO);
		JLabel sO = new JLabel("2. Construct a Rectangle\n");
		f.add(sO);
		JLabel tO = new JLabel("3. Construct a Square\n");
		f.add(tO);
		JLabel foO = new JLabel("4. Construct a Triangle");
		f.add(foO);
		JLabel fiO = new JLabel("5. Construct a Sphere");
		f.add(fiO);
		JLabel siO = new JLabel("6. Construct a Cube");
		f.add(siO);
		JLabel seO = new JLabel("7. Construct a Cone");
		f.add(seO);
		JLabel eiO = new JLabel("8. Construct a Cylinder");
		f.add(eiO);
		JLabel niO = new JLabel("9. Construct a Torus");
		f.add(niO);
		JLabel teO = new JLabel("10. Exit the program");
		f.add(teO);
		JTextField userInput = new JTextField(15);
		JButton submit = new JButton("Submit");
		f.add(submit);
		f.add(userInput);
		submit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				input = userInput.getText();
				d = Integer.parseInt(input.trim());
				switch (d) {
				case 1:
					Circle circle = new Circle();
					break;
				case 2:
					Rectangle r = new Rectangle();
					break;
				case 3:
					System.out.println("You have selected a Square");
					Square sq = new Square();
					break;
				case 4:
					System.out.println("You have selected a Triangle");
					Triangle t = new Triangle();
					break;
				case 5:
					System.out.println("You have selected a Sphere");
					Sphere sp = new Sphere();
					break;
				case 6:
					System.out.println("You have selected a Cube");
					Cube cu = new Cube();
					break;
				case 7:
					System.out.println("You have selected a Cone");
					Cone co = new Cone();
					break;
				case 8:
					System.out.println("You have selected a Cylinder");
					Cylinder cy = new Cylinder();
					break;
				case 9:
					System.out.println("You have selected a Torus");
					Torus to = new Torus();
					break;
				case 10:
					//Used https://www.javatpoint.com/java-get-current-date as a reference
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"); 
					LocalDateTime now = LocalDateTime.now();  
					System.out.println("Thanks for using the program. \nToday's Date and Time: " + dtf.format(now) );
					System.exit(0);
					break;
					
				}
			}
		});
		
		
		
		f.setVisible(true);
	}
	
	public static void main(String[] args) {
		int counter = 0;
		if(counter == 0) {
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				new Driver();
			}
		});}
		
		counter++;
	}
}
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class Square extends Frame {
	JFrame f = new JFrame("Square");
	int length, width, d;

	public Square() {
		super("Square");
		setSize(700,700);
		setWidthAndLength();
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
	}
	

	public void paint(Graphics g) {
		g.drawRect(200, 200, width,length);
	}

	public void setWidthAndLength() {
		JFrame f = new JFrame("Enter Square Size");
		f.setLayout(new GridLayout(0,1));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(500,200);
		
		JTextField t1 = new JTextField(10);
		f.add(t1);
		JButton b1 = new JButton("Submit");
		f.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String userInput = t1.getText();
				d = Integer.parseInt(userInput.trim());
				width = d;
				length = d;
				f.setVisible(false);
				showSquare();
			}
		});
		f.setVisible(true);
	}
	
	public void showSquare() {
		repaint();
		setVisible(true);
		
	}
}
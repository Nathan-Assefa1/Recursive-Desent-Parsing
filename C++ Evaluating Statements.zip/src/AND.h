class AND: public SubExpression
{
public:
    AND(Expression* left, Expression* right): SubExpression(left, right)
    {
    }
    int evaluate()
    {
        if(left->evaluate() ==1 && right->evaluate() == 1 || left->evaluate() ==0 && right->evaluate() == 0)
            return 1;

        else
            return 0;


    }
};

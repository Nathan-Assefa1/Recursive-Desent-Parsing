class Expression
{
public:
    virtual int evaluate() = 0;
};
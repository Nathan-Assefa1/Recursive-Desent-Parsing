class Factorial: public SubExpression
{
public:
    Factorial(Expression* left, Expression* right): SubExpression(left, right)
    {
    }
    int evaluate(){
        int factorial = 1;
        for(int i=1; i<=left->evaluate(); i++){
            factorial *= i;
        }
        return factorial;
    }
};

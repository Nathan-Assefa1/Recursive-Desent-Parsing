#include <iostream>
using namespace std;

#include "expression.h"
#include "subexpression.h"
#include "operand.h"
#include "plus.h"
#include "minus.h"
#include "Times.h"
#include "Divide.h"
#include "AND.h"
#include "Equals.h"
#include "Factorial.h"
#include "GreaterThan.h"
#include "LessThan.h"
#include "OR.h"


SubExpression::SubExpression(Expression* left, Expression* right)
{
    this->left = left;
    this->right = right;
}

Expression* SubExpression::parse()
{
    Expression* left;
    Expression* right;
    char operation, paren;

    left = Operand::parse();
    cin >> operation;
    right = Operand::parse();
    cin >> paren;
    switch (operation)
    {
        case '+':
            return new Plus(left, right);
        case '-':
            return new Minus(left, right);
        case '*':
            return new Times(left, right);
        case '/':
            return new Divide(left, right);
        case '&':
            return new AND(left, right);
        case '=':
            return new Equals(left, right);
        case '!':
            return new Factorial(left, right);
        case '>':
            return new GreaterThan(left, right);
        case '<':
            return new LessThan(left, right);
        case '|':
            return new OR(left, right);

    }
    return 0;
}
        
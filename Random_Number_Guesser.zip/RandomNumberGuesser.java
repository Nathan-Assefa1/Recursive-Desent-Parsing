import java.util.Scanner;

/**
 * The purpose of this class is to ask for a user to guess a number, validate
 * it, and determine whether or not it matches the random number that was
 * generated. If it matches, the program will ask if the user would like to play
 * again. If it doens't match, the program will continue to ask for the user's
 * guess. With each guess, the program will say if the guess is too high or too
 * low and readjust the range from which the user can guess from.
 * 
 * @author Nathan Assefa
 *
 */
public class RandomNumberGuesser {

	public static void main(String[] args) {
		boolean again;
		Scanner s = new Scanner(System.in);

		do {
			boolean found = false;
			boolean valid = false;
			again = false;
			RNG.resetCount();
			int num = RNG.rand();
			int min = 0;
			int max = 100;
			int missed = 0;

			System.out.println("\nRandom Number Generator");
			System.out.println("Enter your first guess: "); //Ask user for their guess
			int input = s.nextInt(); // store their input
			valid = RNG.inputValidation(input, min, max); //validate their guess and increment counter variable by 1

			while (valid != true) { //if guess isn't valid, this loop will ask for the user to reinput their guess
				missed++; //the purpose of this variable is to see how many invalid guesses occur 
				input = s.nextInt();
				valid = RNG.inputValidation(input, min, max);
			}

			while (found != true) {
				while (valid != true) {
					missed++;
					input = s.nextInt();
					valid = RNG.inputValidation(input, min, max);
				}
				if (input > num) {
					System.out.println("Number of guesses is " + (RNG.getCount()-missed)); //I subtract here since the getCount method includes both valid and invalid attempts.
					System.out.println("Your guess it too high");
					max = input; //Changing the max value of the range
					System.out.println("Enter your next guess between " + min + " and " + max);
					input = s.nextInt();
					valid = RNG.inputValidation(input, min, max);
					
				} else if (input < num) {
					System.out.println("Number of guesses is " + (RNG.getCount()-missed));
					System.out.println("Your guess it too low");
					min = input; //Changing the min value of the range
					System.out.println("Enter your next guess between " + min + " and " + max);
					input = s.nextInt();
					valid = RNG.inputValidation(input, min, max);
				} else if (input == num) {
					System.out.println("Number of guesses is " + (RNG.getCount()-missed));
					System.out.println("Congratulations, you guessed correctly");
					System.out.println("Try again? (yes or no)");
					String a = s.next();
					if (a.equals("yes")) {
						again = true;
						found = true;
					}
					if (a.equals("no")) {
						System.out.println("Thanks for playing.... \n" + "Programmer: Nathan Assefa");
						break;
					}
				}
			}
		} while (again == true);
		s.close();

	}
}

package application;

/**
 * 
 * @author Nathan Assefa
 *
 * @param <T>
 */
public class TreeNode<T> {
	public String data;
	public TreeNode<T> leftChild;
	public TreeNode<T> rightChild;
		
	
	/**
	 * 
	 * @param dataNode
	 */
	public TreeNode(String dataNode) {
		this.data = dataNode;
		leftChild = rightChild = null;
		
	}
	
	/**
	 * 
	 * @param node
	 */
	public TreeNode(TreeNode<T> node) {
		
	}

	/**
	 * 
	 * @param dataset
	 */
	public void setData(String dataset) {
		data = dataset;
	}
	
	/**
	 * 
	 * @return data
	 */
	public String getData() {
		return data;
	}
	
	/**
	 * 
	 * @return leftChild
	 */
	public boolean hasLeftChild() {
		return leftChild != null;
	}
	
	/**
	 * 
	 * @return rightChild
	 */
	public boolean hasRightChild() {
		return rightChild != null;
	}
	
	/**
	 * 
	 * @return leftChild
	 */
	public TreeNode<T> getLeftChild(){
		return leftChild;
	}
	
	/**
	 * 
	 * @return rightChild
	 */
	public TreeNode<T> getRightChild(){
		return rightChild;
	}
	
	public void setLeftChild(TreeNode<T> leftChild){
		this.leftChild = leftChild;
	}
	
	public void setRightChild(TreeNode<T> rightChild){
		this.rightChild = rightChild;
	}
}

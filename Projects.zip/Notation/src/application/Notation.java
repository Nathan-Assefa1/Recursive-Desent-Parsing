package application;

import java.util.Stack;
/**
 * 
 * @author Nathan Assefa
 *
 * @param <T>
 */
public class Notation<T> {
	 
	    /**
	     * This method takes in an infix expression and converts it into a postfix
	     * expression. 
	     * 
	     * @param infix
	     * @return postfix which is the converted infix
	     * @throws InvalidNotationFormatException
	     */
	
	public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException{
		NotationStack<String> postStack = new NotationStack<String>();
		NotationQueue<String> postfixQueue = new NotationQueue<String>();
	    String postfix = "";
	    int leftCount=0, rightCount=0;
	    boolean leftParen = false;
	    int size = infix.length(), counter=0;
	    char[] postChar = new char[size];
	    
	    for(int i=0; i<size; i++) {
	    	postChar[i] = infix.toCharArray()[i];
	    }
		
	    
	    for(int i=0; i<size; i++) {
			if(Character.isDigit(infix.charAt(i))) { 
				try {
					postfixQueue.enqueue(String.valueOf(postChar[i]));
				} catch (QueueOverflowException e) {
					throw new InvalidNotationFormatException();				}
			}
			else if(infix.charAt(i) == '(') {
				try {
					leftCount++;
					postStack.push("(");
				} catch (StackOverflowException e) {
					throw new InvalidNotationFormatException();				}
			} 
			
			else if(infix.charAt(i) == '*' || infix.charAt(i) == '/') {
					 
						try {
							String top = postStack.top();
							if(top.equals("*") || top.equals("/") ) {
							try {
							postfixQueue.enqueue(postStack.pop());}
							catch (QueueOverflowException e) {
								throw new InvalidNotationFormatException();
							} catch (StackUnderflowException e) {
								throw new InvalidNotationFormatException();							}
							}
						} catch (StackUnderflowException e1) {
							throw new InvalidNotationFormatException();						}
						try {
							postStack.push(String.valueOf(infix.charAt(i)));
						} catch (StackOverflowException e) {
							throw new InvalidNotationFormatException();						}

				}
			else if(infix.charAt(i) == '+' || infix.charAt(i) == '-') {
						try {
							String top = postStack.top();
							if(top.equals("+") || top.equals("-")||top.equals("*") || top.equals("/") ) {
								try {
								postfixQueue.enqueue(postStack.pop());
								} catch (QueueOverflowException e) {
									throw new InvalidNotationFormatException();}
									catch (StackUnderflowException e) {
										throw new InvalidNotationFormatException();								}
							}
						} catch (StackUnderflowException e1) {
							throw new InvalidNotationFormatException();						}
							
						try {
							postStack.push(String.valueOf(infix.charAt(i)));
							}catch (StackOverflowException e) {
								throw new InvalidNotationFormatException();							}
							

			
			}
			
			else if(infix.charAt(i) == ')') {
				rightCount++;
			
					try {
						
						String top = postStack.top();
						while(!(postStack.isEmpty())){
							if(top.equals("(")) {
								postStack.pop();
								leftCount--;
								break;
							}
							else {
							try {
							postfixQueue.enqueue(postStack.pop());
							} catch (StackUnderflowException e) {
								throw new InvalidNotationFormatException();}
								catch (QueueOverflowException e) {
									throw new InvalidNotationFormatException();}							}
						top = postStack.top();
						}
						
					} catch (StackUnderflowException e) {
						throw new InvalidNotationFormatException();					}
					rightCount--;

			}
			

	    }
	    if(!postStack.isEmpty() && leftCount!=rightCount) {
			throw new InvalidNotationFormatException();
		}
			
		for(int j=0; j<size; j++ ) {
			while(!(postfixQueue.isEmpty())){
			try {
				postfix += postfixQueue.dequeue();
			} catch (QueueUnderflowException e) {
				throw new InvalidNotationFormatException();}
			}
		}
	    
	    
		return postfix;
	}
	
	
	
	/**
	 * This method takes in a postfix expression and converts it into an infix
	 * expression. 
	 *      
	 * @param postfix
	 * @return finalString
	 * @throws InvalidNotationFormatException
	 */
	public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException{
		NotationStack<String> pile = new NotationStack<>();
		int counter=0;
		
		String finalString = "";
		int size = postfix.length(), count=0;
	    char[] postChar = new char[size];
	    
	    for(int i=0; i<size; i++) {
	    	postChar[i] = postfix.toCharArray()[i];
	    }
	    
	    for(int i=0; i<size; i++) {
	    	if(Character.isDigit(postfix.charAt(i))){
	    			try {
						pile.push(String.valueOf(postfix.charAt(i)));
					} catch (StackOverflowException e) {
						new StackOverflowException();
					}finally{
			    		count++;
					}
	    	}
	    	else if(postfix.charAt(i) == '*') {
	    		counter++;
	    		String operand1="", operator="", operand2="";
	    		if(count>=2 && count>counter) {
	    			try {
	    			operand1 = pile.pop();
	    			operator = "*";
	    			operand2=pile.pop();
	    			}catch(StackUnderflowException e) {
	    				new StackUnderflowException();
	    			}
	    			String sum = "("+operand2 + operator + operand1+")";
	    			try {
						pile.push(sum);
					} catch (StackOverflowException e) {
						new StackOverflowException();
					}	    		}
	    		else
	    			throw new InvalidNotationFormatException();
	    	}
	    	else if(postfix.charAt(i) == '/') {
	    		counter++;
	    		String operand1="", operator="", operand2="";
	    		if(count>=2 && count>counter) {
	    			try {
	    			operand1 = pile.pop();
	    			operator = "/";
	    			operand2=pile.pop();
	    			}catch(StackUnderflowException e) {
	    				new StackUnderflowException();
	    			}
	    			String sum = "("+operand2 + operator + operand1+")";
	    			try {
						pile.push(sum);
					} catch (StackOverflowException e) {
						new StackOverflowException();
					}	    		}
	    		else
	    			throw new InvalidNotationFormatException();
	    	}
	    	else if(postfix.charAt(i) == '+') {
	    		counter++;
	    		String operand1="", operator="", operand2="";
	    		if(count>=2 && count>counter) {
	    			try {
	    			operand1 = pile.pop();
	    			operator = "+";
	    			operand2=pile.pop();
	    			}catch(StackUnderflowException e) {
	    				new StackUnderflowException();
	    			}
	    			String sum = "("+operand2 + operator + operand1+")";
	    			try {
						pile.push(sum);
					} catch (StackOverflowException e) {
						new StackOverflowException();
					}
	    		}
	    		else
	    			throw new InvalidNotationFormatException();
	    	}
	    	
	    	else if(postfix.charAt(i) == '-') {
	    		counter++;
	    		String operand1="", operator="", operand2="";
	    		if(count>=2 && count>counter) {
	    			try {
	    			operand1 = pile.pop();
	    			operator = "-";
	    			operand2=pile.pop();
	    			}catch(StackUnderflowException e) {
	    				new StackUnderflowException();
	    			}
	    			String sum = "("+operand2 + operator + operand1+")";
	    			try {
						pile.push(sum);
					} catch (StackOverflowException e) {
						new StackOverflowException();
					}
	    		}
	    		else
	    			throw new InvalidNotationFormatException();
	    		}
	
	    	}
	    	
	    
	    
	    if(pile.size()!=1) {
	    	throw new InvalidNotationFormatException();
	    } else {
			try {
				finalString = pile.pop();
			} catch (StackUnderflowException e) {
				new StackUnderflowException();
			}
	    }
	    
		return finalString;		
	}
	
	
	/**
	 * This method takes in a postfixExpr and evaluates the answer of the equation
	 * @param postfixExpr
	 * @return total
	 * @throws InvalidNotationFormatException
	 */
	public static double evaluatePostfixExpression(String postfixExpr) throws InvalidNotationFormatException {
		NotationStack<String> pile = new NotationStack<String>();
		int size = postfixExpr.length();
	    char[] postChar = new char[size];
	    double total=0;
	   int counter=0, count=0;
	    for(int i=0; i<size; i++) {
	    	postChar[i] = postfixExpr.toCharArray()[i];
	    }
	    
	    for(int i=0; i<size; i++) {
	    	if(Character.isDigit(postfixExpr.charAt(i))){
	    			try {
						pile.push(String.valueOf(postChar[i]));
					} catch (StackOverflowException e) {
						throw new InvalidNotationFormatException();
						}finally{
			    		++count;
					}
	    	}
	    	
	    	else if(postChar[i] == '*') {
	    		counter++;
	    		
		    if(count>=2) {
		    	if(count>counter) {
	    			try {
						double operand1 = Double.parseDouble(pile.pop());
						double operand2 = Double.parseDouble(pile.pop());
					    double sum = operand2 * operand1;
					    String sum1 = String.valueOf(sum);
						pile.push(sum1);	
	    		} catch (StackOverflowException e) {
					throw new InvalidNotationFormatException();				}
			    catch (StackUnderflowException e) {
					throw new InvalidNotationFormatException();				}
		    	}	
	    		
	    	}
		    		else {
	    				throw new InvalidNotationFormatException();
	    			}
	    	}
	    		
	    		else if(postChar[i] == '+') {
		    		counter++;

		    		if(count>=2 && count>counter) {
	    			try {
	    				double operand1 = Double.parseDouble(pile.pop());
						double operand2 = Double.parseDouble(pile.pop());
					    double sum = operand2 + operand1;
					    String sum1 = String.valueOf(sum);
					    try {
							pile.push(sum1);
					    } catch (StackOverflowException e) {
							throw new InvalidNotationFormatException();						}
					    
	    		} catch (StackUnderflowException e) {
					throw new InvalidNotationFormatException();				}
	    	}
		    		else{
	    				throw new InvalidNotationFormatException();
	    			}
	    		}
	    		
	    		else if(postChar[i] == '-') {
		    		counter++;

		    		if(count>=2 && count>counter) {
	    			try {
	    				double operand1 = Double.parseDouble(pile.pop());
						double operand2 = Double.parseDouble(pile.pop());
					    double sum = operand2 - operand1;
					    String sum1 = String.valueOf(sum);
					    try {
							pile.push(sum1);
						} catch (StackOverflowException e) {
							throw new InvalidNotationFormatException();						}
					    
	    		} catch (StackUnderflowException e) {
					throw new InvalidNotationFormatException();				}
	    	}
		    		else{
	    				throw new InvalidNotationFormatException();
	    			}
	    		}
	    		else if(postChar[i] == '/') {
		    		counter++;
		    		
		    		if(count>=2 && count>counter) {
			    		
	    			try {
	    				double operand1 = Double.parseDouble(pile.pop());
						double operand2 = Double.parseDouble(pile.pop());
					    double sum = operand2 / operand1;
					    String sum1 = String.valueOf(sum);
					    try {
							pile.push(sum1);
						} catch (StackOverflowException e) {
							throw new InvalidNotationFormatException();						}
					    
	    		} catch (StackUnderflowException e) {
					throw new InvalidNotationFormatException();				}
	    	}
		    		else{
	    				new InvalidNotationFormatException();
	    			}
	    		}
	    	
	}
	
	    if(pile.size()!=1) {
			new InvalidNotationFormatException();
		}
    	else {
			try {
				total = Double.parseDouble(pile.pop());
			} catch (StackUnderflowException e) {
				new StackUnderflowException(); }
			}
	
	    return total;
	}
	

	


	
	/**
	 * This method calls two of my previous method to make the process more efficient.
	 * This takes in an infix expression and evaulates the answer. 
	 * @param infixExpr
	 * @return total
	 * @throws InvalidNotationFormatException
	 */
	public static double evaluateInfixExpression(String infixExpr) throws InvalidNotationFormatException{
		String postfixExpr = "";
		double total;
		postfixExpr = convertInfixToPostfix(infixExpr);
		total = evaluatePostfixExpression(postfixExpr);
		return total;
		}
	

	}

	
	
	
	
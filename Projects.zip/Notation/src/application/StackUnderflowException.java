package application;

public class StackUnderflowException extends Exception {
	public StackUnderflowException() {
		super("The set is empty");
	}
}

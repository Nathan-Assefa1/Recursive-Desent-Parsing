package application;

public class InvalidNotationFormatException extends Exception {
	public InvalidNotationFormatException() {
		super("Invalid Notation Format");
	}
}

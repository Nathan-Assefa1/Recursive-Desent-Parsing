package application;

public class QueueOverflowException extends Exception {
	public QueueOverflowException() {
		super("There is no more space in the queue");
	}
}

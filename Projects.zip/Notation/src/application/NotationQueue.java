package application;

import java.util.ArrayList;
import java.util.Queue;

/**
 * 
 * @author Nathan Assefa
 *
 * @param <T>
 */

public class  NotationQueue<T> implements QueueInterface<T>{
	private ArrayList<T> list;
	int size;
	int numOfItems=0;
	

	public NotationQueue() {
		this.size = 500;
		list = new ArrayList<T>();	
		}
	
	public NotationQueue(int size) {
		this.size = size;
		list = new ArrayList<T>();	
		}
	
	/**
	 * Deletes and returns the element at the front of the Queue
	 * @return the element at the front of the Queue
	 */
	public T dequeue() throws QueueUnderflowException {
		if(isEmpty())
			throw new QueueUnderflowException();
		else {
			T result = list.get(0);
			list.remove(0);
			numOfItems--;
			return result;
		}
			
	}
	
	/**
	 * Adds an element to the end of the Queue
	 * @param e the element to add to the end of the Queue
	 * @return true if the add was successful, false if not
	 */
	public boolean enqueue(T item) throws QueueOverflowException {
		
		if(isFull()) {
			throw new QueueOverflowException();
		}
		else {
		list.add(item);
		numOfItems++;
		return true;
		}
	}
	
	/**
	 * Determines of the Queue is empty
	 * @return
	 */
	
	public boolean isFull() {
		if(list.size() == size)
			return true;
		else
			return false;
	}


	public T getFront() {
		return list.get(0);
	}
	
	public void clear() {
		list.clear();
	}
	
	/**
	 * Determines if Queue is empty
	 * @return true if Queue is empty, false if not
	 */
	public boolean isEmpty() {
		return list.isEmpty();
	}
	

	/**
	 * Number of elements in the Queue
	 * @return the number of elements in the Queue
	 */
	public int size() {
		return numOfItems;
	}

	/**
	 * Returns the string representation of the elements in the Queue, 
	 * the beginning of the string is the front of the queue
	 * @return string representation of the Queue with elements
	 */
	public String toString() {
		String queueString = "";
		for(T var: list) {
			queueString += var;
		}
		return queueString;
	}
	
	/**
	 * Returns the string representation of the elements in the Queue, the beginning of the string is the front of the queue
	 * Place the delimiter between all elements of the Queue
	 * @return string representation of the Queue with elements separated with the delimiter
	 */
	public String toString(String delimiter) {
		String queueString = "";
		for(T var: list) {
			queueString += (var + delimiter);
		}
		String queueString2="";
		for(int i=0; i<(queueString.length()-1); i++) {
			queueString2 += queueString.toCharArray()[i];
		}
		return queueString2;	}

	/**
	  * Fills the Queue with the elements of the ArrayList, First element in the ArrayList
	  * is the first element in the Queue
	  * YOU MUST MAKE A COPY OF LIST AND ADD THOSE ELEMENTS TO THE QUEUE, if you use the
	  * list reference within your Queue, you will be allowing direct access to the data of
	  * your Queue causing a possible security breech.
	  * @param list elements to be added to the Queue
	  */
	public void fill(ArrayList<T> list) {
			QueueInterface<T> queueList = new NotationQueue<T>(size);
			
			for(T var : list)
				try {
					enqueue(var);
				}
			catch(QueueOverflowException e) {
				e.printStackTrace();
			}
	}


}
package application;

public class EmptyQueueException extends Exception {
	public EmptyQueueException() {
		super("The password must be at least 6 characters long");
	}
}

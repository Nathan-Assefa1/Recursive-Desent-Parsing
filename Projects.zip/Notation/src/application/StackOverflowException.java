package application;

public class StackOverflowException extends Exception {
	public StackOverflowException() {
		super("The stack is full");
	}
}
